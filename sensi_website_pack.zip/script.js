async function findSensi(){

let model = document.getElementById("model").value;

let res = await fetch("database.json");
let data = await res.json();

let device = data.find(d =>
d.model.toLowerCase() === model.toLowerCase()
);

if(device){

document.getElementById("result").innerHTML =
"Fire Button : "+device.fire+"<br>"+
"Red Dot : "+device.redDot+"<br>"+
"Scope : "+device.scope;

}else{
document.getElementById("result").innerText="Device Not Found";
}

}
